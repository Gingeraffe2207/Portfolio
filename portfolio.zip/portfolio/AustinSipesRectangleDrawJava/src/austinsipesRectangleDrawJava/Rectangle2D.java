/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package austinsipeslab3;

public class Rectangle2D {
    private double x;
    private double y;
    private double width;
    private double height;
    
    public Rectangle2D(){
        x = 0;
        y = 0;
        width = 1;
        height = 1;
    }
    
    public Rectangle2D(double x, double y, double width, double height){
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }
    
    public double getX(){
        return x;
    }
    
    public void setX(double newX){
        x = newX;
    }
    
    public double getY(){
        return y;
    }
    
    public void setY(double newY){
        y = newY;
    }
    
    public double getWidth(){
        return width;
    }
    
    public void setWidth(double newWidth){
        width = newWidth;
    }
    
    public double getHeight(){
        return height;
    }
    
    public void setHeight(double newHeight){
        height = newHeight;
    }
    
    public String toString(){
        return ("This Rectangle has a width of "+width+" , height of "
                +"and cneter point at ("+x+", "+y+")");
    }
    
    public double getArea(){
        return width*height;
    }
    
    public double getPerimeter(){
        return (width*2)+(height*2);
    }
    
    public boolean contains(double x, double y){
        return ((x < this.x+(width/2) && x > this.x-(width/2))
                && (y < this.y+(height/2) && y > this.y-(height/2)));
    }
    
    public boolean contains(Rectangle2D rectangle){
        if (contains(rectangle.x, rectangle.y)){
            return((rectangle.x + (rectangle.width/2) < x+(width/2))
                    && (rectangle.x - (rectangle.width/2) > x-(width/2)) 
                    && (rectangle.y + (rectangle.height/2) < y+(height/2))
                    && (rectangle.y - (rectangle.height/2) > y+(height/2)));
        }
        else
            return false;
    }
    
    public boolean overlaps(Rectangle2D rectangle){
        if (contains(rectangle.x, rectangle.y)){
            if(contains(rectangle))
                return false;
            else
                return true;
        }
        else
            return false;
    }
}
