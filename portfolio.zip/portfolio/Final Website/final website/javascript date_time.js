<script type="text/javascript">
	document.write("<p>The date is " + Date() + "</p>");
</script>