/*
Project: NestedLopps
authour: Austin Sipes
purpose: build a multiplication table
    1  2  3  4
1   1  2  3  4
2   2  4  6  8
3   3  6  9  12
4   4  8  12 16
 */
package p0119c;

public class P0119c {

    public static void main(String[] args) {
        //Display the number titles
        System.out.print("");
        for(int n = 1; n<=9; n++){
            System.out.print("   " + n);
        }
        //print the table body
        System.out.println("\n---------------------------------------");
        for(int r = 1; r<=9; r++){ //outer loop prints rows at a time
            System.out.println( r +"|");
            for(int c=1; c<=9; c++){
                System.out.printf("%4d", c*r);
            }
        }
    }
    
}
