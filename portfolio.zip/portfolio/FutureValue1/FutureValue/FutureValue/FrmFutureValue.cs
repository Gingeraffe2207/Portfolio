﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FutureValue
{
    public partial class FrmFutureValue : Form
    {
        public FrmFutureValue()
        {
            InitializeComponent();
        }

        string[,] values = new string[10, 4];

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            //Declare local variables
            decimal MonthlyInvestment;
            decimal YearlyInterestRate;
            int Years;
            int Months;
            decimal MonthlyInterestRate;
            decimal FutureValue;

            try //Convert the input data
            {
                MonthlyInvestment = Convert.ToDecimal(txtMonthlyInvestment.Text);
                YearlyInterestRate = Convert.ToDecimal(txtYearlyInterestRate.Text);
                Years = Convert.ToInt32(txtNumOfYears.Text);
                Months = Years * 12;
                MonthlyInterestRate = YearlyInterestRate / 12 / 100;
                FutureValue = 0m;

                for (int i = 0; i < Months; i++)
                {
                    FutureValue = (FutureValue + MonthlyInvestment) * (1 + MonthlyInterestRate);
                }

                txtFutureValue.Text = FutureValue.ToString("C");
                txtMonthlyInvestment.Focus();
            }

            catch //there was a problem with the input data.
            {
                MessageBox.Show("The input data must be numeric. \n\nPlease retry.");
            }
        }

        void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtFutureValue.Text = "";
            txtMonthlyInvestment.Text = "";
            txtNumOfYears.Text = "";
            txtYearlyInterestRate.Text = "";
        }
    }
}
