<!DOCTYPE html>
<html>
<head><meta charset="UTF-8" />
	<title>welcome php</title>
</head

<body>
	Welcome
	<?php
		echo $_POST["name"];
	?>
	<br/>
	Your phone number is:
	<?php
		echo $_POST["phone"];
	?>
	<br/>
	your requested song:
	<?php
		echo $_POST["songName"];
	?>
	<br/>
	Song Artist:
	<?php
		echo $_POST["artist"];
	?>
</body>
</html>