//Change the Background Color
<p><input type="button" value="Blue" onclick="chBackcolor('#0099cc');">
<p><input type="button" value="Pink" onclick="chBackcolor('#ff66cc');">
<p><input type="button" value="Purple" onclick="chBackcolor('#a366ff');">
<p><input type="button" value="Orange" onclick="chBackcolor('#ff9933');">
<p><input type="button" value="Green" onclick="chBackcolor('#66ff99');">

<script type="text/javascript">
function chBackcolor(color) {
   document.body.style.background = color;
}
</script>