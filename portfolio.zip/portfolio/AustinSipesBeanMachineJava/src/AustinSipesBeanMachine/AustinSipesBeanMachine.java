/*
authour: Austin Sipes
purpose: Simulate a bean machine

*/
package austinsipeslab4;
import java.util.Scanner;

public class AustinSipesLab4 {

    public static void main(String[] args) {
        double direction;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter number of slots for the bean machine: ");
        int nSlots = input.nextInt();
        System.out.print("Enter the number of balls to drop in the machine: ");
        int balls = input.nextInt();
        
        int slots[];
        slots = new int[nSlots];
        
        char path[];
        path = new char[nSlots-1];
        
        System.out.println("Here is a summary of the path each ball took.");
        for(int i=0; i<balls; i++){
            int leftCount = 0;
            //simulate the path of the ball with this for loop
            for(int nail = 0; nail < nSlots-1; nail++){
                direction = Math.floor(Math.random()*2);
                if (direction == 0){
                    path[nail] = 'L';
                    leftCount++;
                }
                else{
                    path[nail] = 'R';
                }
            }
            //calculate which slot the ball fell into
            for(int k=0; k<nSlots-1; k++){
                if(leftCount == nSlots-1 - k)
                    slots[k] += 1;
            }
            
            //print out the path the ball took
            for(int j=0; j < nSlots-1; j++){
            System.out.print(path[j]);
            }
            System.out.println();
        }
        System.out.println("Here is how many balls are in each slot");
        for(int x = 0; x<slots.length; x++){
            System.out.print(slots[x]);
        }
    }//close main
    
}
