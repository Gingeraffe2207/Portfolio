/*
authour: Austin Sipes
purpose: Draw a rectangle given the diemensions from the user.

 */
package austinsipeslab3;

import java.util.Scanner;

public class AustinSipesLab3 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Rectangle2D r1 = new Rectangle2D();
        System.out.print("Enter an X center point value ");
        double x2 = input.nextInt();
        System.out.print("Enter a Y center point value ");
        double y2 = input.nextInt();
        System.out.print("Enter the rectangle's width ");
        double width2 = input.nextInt();
        System.out.print("Enter the rectangle's height ");
        double height2 = input.nextInt();
        Rectangle2D r2 = new Rectangle2D(x2, y2, width2, height2);
        
        System.out.println("The area of rectangle 1 is: "+r1.getArea());
        System.out.println("The perimeter of rectangle 1 is: "+r1.getPerimeter());
        System.out.println("The area of rectangle 2 is: "+r2.getArea());
        System.out.println("The perimeter of rectangle 2 is: "+r2.getPerimeter());
        
        System.out.println("does Rectangle 1 contain rectangle 2? "+r1.contains(r2));
        System.out.println("does rectangle 2 overlap rectangle 1? "+r2.overlaps(r1));
        
        System.out.print("enter an x value for containment comparison ");
        double testX = input.nextInt();
        System.out.print("enter a Y value for containment comparison ");
        double testY = input.nextInt();
        System.out.println("is ("+testX+","+testY+") inside rectangle 1? "+r1.contains(testX, testY));
        System.out.println("is ("+testX+","+testY+") inside rectangle 2? "+r2.contains(testX, testY));
        System.out.println(r1);
        System.out.println(r2);
        
        System.out.print("Enter a new X center point value for rectangle 1");
        double x1 = input.nextInt();
        r1.setX(x1);
        
        System.out.print("Enter a new Y center point value for rectangle 1");
        double y1 = input.nextInt();
        r1.setY(y1);
        
        System.out.print("Enter the rectangle 1's new width ");
        double width1 = input.nextInt();
        r1.setWidth(width1);
        
        System.out.print("Enter the rectangle 1's new height ");
        double height1 = input.nextInt();
        r1.setHeight(height1);
        
        System.out.println("The area of rectangle 1 is: "+r1.getArea());
        System.out.println("The perimeter of rectangle 1 is: "+r1.getPerimeter());
        System.out.println("The area of rectangle 2 is: "+r2.getArea());
        System.out.println("The perimeter of rectangle 2 is: "+r2.getPerimeter());
        
        System.out.println("does Rectangle 1 contain rectangle 2? "+r1.contains(r2));
        System.out.println("does rectangle 2 overlap rectangle 1? "+r2.overlaps(r1));
    }
    
}
