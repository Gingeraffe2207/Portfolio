/*
authour: Austin Sipes
purpose: This program has 2 functions: password generation and password validation
these functions are presented to the user as menu options

Password Validation:
verify passwords only contain letters and digits,
have 8 or more characters, and 2 or more numbers

Random password Generator:
generate passwords using user requests
in the form of: uppercaseletters+number+lowercaseletters+number+symbol
 */
package p0131a;

import java.util.Scanner;

public class P0131a {
    
    public static void main(String[] args) {
        java.util.Scanner input = new java.util.Scanner(System.in);
        String choice = "";
        
        do{
            System.out.println("g. Generate password");
            System.out.println("v. validate password");
            System.out.println("e. Exit");
            System.out.print("Pick an option from the menu above: ");
            choice = input.next();
            
            switch(choice.charAt(0)){
                case 'g' : case 'G':
                    //code for generate password
                    //System.out.println(getRandomChar('a', 'z')); <-test for 1st method
                    String password = "";
                    //ask user how many upper case letters
                    System.out.println("How many upper case letters for your password?");
                    int upper = input.nextInt();
                    
                    //add the number of uppercase letters to the password
                    for(int i=0; i<upper; i++)
                        password += getRandomUpperLetter();
                    
                    //add random digit to the password
                    password += getRandomInteger();
                    //ask the user for how many lowercase letters
                    System.out.println("How many upper case letters for your password?");
                    int lower = input.nextInt();
                    
                    //add the number of lowercase letters to password
                    
                    
                    for(int i=0; i<lower; i++)
                        password += getRandomLowerLetter();
                    
                    //add random digit to the password
                    password += getRandomInteger();
                    //add random symbol to the password
                    password += getRandomSymbol();
                    
                    //output password
                    System.out.println("your password is: "+password);
                    break; //ends the switch
                case 'v' : case 'V':
                    //code for validate password
                    System.out.print("Enter a String for password: ");
                    String s = input.next();
                    
                    //check the inputted password
                    if(isValidPassword(s)){
                        System.out.println("Valid password");
                    }
                    else
                        System.out.println("Invalid password");
                    break;
                case 'e': case 'E' :
                    System.out.print("Goodbye!");
                    break;
                default:
                    System.out.println("You typed an invalid menu choice. Try again.");    
            }
        }while(choice.charAt(0) != 'e' && choice.charAt(0) != 'E');
    }
    
    public static boolean isValidPassword(String s){
        //only contains letters and digits? If not, return false
        // if so, check other conditions
        for(int i = 0; i<s.length(); i++){
            if(!(isLetter(s.charAt(i))) && !(isDigit(s.charAt(i))))
                return false;
        }
        //check the length return false if length <8
        if(s.length()<8)
            return false;
        int count = 0;
        
        
    }//close isValidPassword
    
    public static boolean isLetter(char letter){
        if((int)letter >=65 && (int)letter <=90 || ((int)letter>=97 && (int)letter <=122))
            return true;
        else
            return false;
    }
    
    public static boolean isDigit(char letter){
        if((int)letter >=65/*<- insert ASCII min here */ && (int)letter <=90 || ((int)letter>=97 && (int)letter <=122))
            return true;
        else
            return false;
    }
    
    public static char getRandomChar(char char1, char char2){
        
        return (char)(char1 + Math.random()*( char2 - char1 +1));
    }
    
    public static char getRandomUpperLetter(){
        return getRandomChar('A', 'Z');
    }
    
    public static char getRandomLowerLetter(){
        return getRandomChar('a', 'z');
    }
    
    public static char getRandomInteger(){
        return getRandomChar('0', '9');
    }
    
    public static char getRandomSymbol(){
        return getRandomChar('!', '&');
    }
    
}
