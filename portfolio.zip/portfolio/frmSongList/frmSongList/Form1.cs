﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace frmSongList
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        

        private void backgroundToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Allow the user to select a different background color for the form.
            DialogResult BackgroundButtonSelection;
            colorDialog1.Color = this.BackColor;
            //show the color selection dialog box
            BackgroundButtonSelection = colorDialog1.ShowDialog();
            if(BackgroundButtonSelection == DialogResult.Cancel) //User did not hit okay
            {
                return; // cancel out of this subroutine
            }
            this.BackColor = colorDialog1.Color;
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Allow the user to select a different foreground (font) color for the form.
            DialogResult FontButtonSelection;
            colorDialog1.Color = this.ForeColor;
            FontButtonSelection = colorDialog1.ShowDialog();
            if (FontButtonSelection == DialogResult.Cancel) //User did not hit okay
            {
                return; // cancel out of this subroutine
            }
            this.ForeColor = colorDialog1.Color;
        }

        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //Display the about box
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //add the selected song to the custom playlist and remove from the master list
            listSelectedSongList.Items.Add(listMasterSongList.SelectedItem);
            listMasterSongList.Items.RemoveAt(listMasterSongList.SelectedIndex);

            //increment the time counter accordingly
            

        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            //Remove the selected song from the custom playlist and add back to the master list
            listMasterSongList.Items.Add(listSelectedSongList.SelectedItem);
            listSelectedSongList.Items.RemoveAt(listSelectedSongList.SelectedIndex);

            //decrement the time counter accordingly
            
        }

        private void btnClearList_Click(object sender, EventArgs e)
        {
            listSelectedSongList.Items.Clear();
        }

        private void btnSaveList_Click(object sender, EventArgs e)
        {
            Stream myStream;
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.RestoreDirectory = true;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if ((myStream = saveFileDialog1.OpenFile()) != null)
                {
                    // Code to write the stream goes here.
                    myStream.Close();
                }
            }
        }

        public void openToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //initialize variables
            string strMasterList;

            var artistNames = new List<string>();
            var songNames = new List<string>();
            var time = new List<string>();

            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Title = "Browse .csv Files";
            
            openFileDialog1.CheckFileExists = true;
            openFileDialog1.CheckPathExists = true;

            openFileDialog1.DefaultExt = ".csv";
            openFileDialog1.Filter = "Csv files (*.csv)|*.csv|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;



            openFileDialog1.ReadOnlyChecked = true;

            openFileDialog1.ShowReadOnly = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //read the contents of the CSV file as individual lines
                var csvLines = File.ReadAllLines(@openFileDialog1.FileName);

                //add the data from the CSV file into the listMasterSongList I have the variables stored seperately to use for other things and for testing here.
                for (int i = 1; i < csvLines.Length; i++)
                {
                    string[] rowData = csvLines[i].Split(',');

                    artistNames.Add(rowData[0]);
                    songNames.Add(rowData[1]);
                    time.Add(rowData[2]);
                    this.listMasterSongList.Items.Add(rowData[0] + " - " + rowData[1] + "\n"); 
                }
            }
            
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
